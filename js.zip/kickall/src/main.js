const Command = require('./command');
const { Message, OpType, Location, Profile } = require('../curve-thrift/line_types');

class LINE extends Command {
    constructor() {
        super();
        this.receiverID = '';
        this.messages;
        this.payload;
    }


    get myBot() {
        const bot = ['ue55fba994594b35fee31890b08aa0e60','uaafb36c69689519fba680c30c14fe923'];
        return bot;
    }

    isAdminOrBot(param) {
        return this.myBot.includes(param);
    }

    getOprationType(operations) {
        for (let key in OpType) {
            if(operations.type == OpType[key]) {
                if(key !== 'NOTIFIED_UPDATE_PROFILE') {
                    console.info(`[# ${operations.type} ] ${key} `);
                }
            }
        }
    }

    poll(operation) {
        if(operation.type == 25) {
            let message = new Message(operation.message);
            this.receiverID = message.to = (operation.message.to === this.myBot[0]) ? operation.message._from : operation.message.to ;
            Object.assign(message,{ ct: operation.createdTime.toString() });
            this.textMessage(message)
        }
        this.getOprationType(operation);
    }

    command(msg, reply) {
        if(this.messages.text !== null) {
            if(this.messages.text === msg.trim()) {
                if(typeof reply === 'function') {
                    reply();
                    return;
                }
                if(Array.isArray(reply)) {
                    reply.map((v) => {
                        this._sendMessage(this.messages, v);
                    })
                    return;
                }
                return this._sendMessage(this.messages, reply);
            }
        }
    }

    async tagall() {
        let rec = await this._getGroup(this.messages.to);
        const mentions = await this.mention(rec.members);
        this.messages.contentMetadata = mentions.cmddata;
        await this._sendMessage(this.messages,mentions.names.join(''));
        return;
    }

    mention(listMember) {
            let mentionStrings = [''];
            let mid = [''];
            for (var i = 0; i < listMember.length; i++) {
                mentionStrings.push('@'+listMember[i].displayName+'\n');
                mid.push(listMember[i].mid);
            }
            let strings = mentionStrings.join('');
            let member = strings.split('@').slice(1);

            let tmp = 0;
            let memberStart = [];
            let mentionMember = member.map((v,k) => {
                let z = tmp += v.length + 1;
                let end = z - 1;
                memberStart.push(end);
                let mentionz = `{"S":"${(isNaN(memberStart[k - 1] + 1) ? 0 : memberStart[k - 1] + 1 ) }","E":"${end}","M":"${mid[k + 1]}"}`;
                return mentionz;
            })
            return {
                names: mentionStrings.slice(1),
                cmddata: { MENTION: `{"MENTIONEES":[${mentionMember}]}` }
            }
        }

    async textMessage(messages) {
        this.messages = messages;
        let payload = (this.messages.text !== null) ? this.messages.text.split(' ').splice(1).join(' ') : '' ;
        let receiver = messages.to;
        let sender = messages.from;

        this.command('.menu', ['╭──────────────╼\n┝──────────────╼\n│𐀀 TEAMBOT LINUX\n┝──────────────╼\n│⊳ .grouplist\n│⊳ .speed\n│⊳ .kickall\n│⊳ .cancelall\n│⊳ .tagall\n│⊳ Bypass [❗]\n┝──────────────╼\n╰──────────────╼\n\nhttps:line.me/ti/p/~.addline']);
        this.command('.speed', this.getSpeed.bind(this));
        this.command('.response', 'READY❗');
        this.command('.me', this.contact.bind(this));
        this.command('.grouplist', this.checkGroup.bind(this));
        this.command('.tagall', this.tagall.bind(this));
        this.command('.kickall', this.kickAll.bind(this));
        this.command('.cancelall',this.cancelAll.bind(this));
        this.command('❗', this.Bypass.bind(this));

    }

}

module.exports = LINE;
